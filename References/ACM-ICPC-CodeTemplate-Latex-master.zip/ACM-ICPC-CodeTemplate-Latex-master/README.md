ACM-ICPC Code Template & LATEX
==============================
Generate ACM-ICPC Code Template with Latex fashion.<br/>
(1) Write code.<br/>
(2) Change the config file.
Usage
-----
    make
**./config:** the directory you sort in pdf file.<br/>
**./$directory/config:** the code you wirte and the name you want to display in pdf file.<br/>
**head:** you can change the author here.<br/>
Code inside is for fun, that's all.<br />
